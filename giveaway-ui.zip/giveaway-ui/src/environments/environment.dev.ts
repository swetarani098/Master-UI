export const environment = {
    production: false,
    apiHost: '',
    CONSUMER_KEY : 'someReallyStupidTextWhichWeHumansCantRead', 
    codes: [ 'AB', 'AC', 'XYZ' ],
    projectTitle: 'Crescent',
    endpoint: 'http://localhost:8080/'
};