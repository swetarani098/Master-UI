export const environment = {
  production: false,
  apiHost: '',
  CONSUMER_KEY : 'someReallyStupidTextWhichWeHumansCantRead', 
  codes: [ 'AB', 'AC', 'XYZ' ],
  projectTitle: 'Crescent',
  endpoint: 'http://172.18.2.50:7706/eventmanagementservice/',
  userManagementBaseUrl: 'http://172.18.2.50:7706/giveaway-usermanagement/',
  inventoryManagementBasUrl: 'http://172.18.2.50:7706/giveaway-inventorymanagement/',
  reportendpont: 'http://172.18.2.50:7706/giveawayreportingservice/',
  mailBasUrl: 'http://172.18.2.50:7706/mailingsystem/'
};