import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-inbox',
  templateUrl: './my-inbox.component.html',
  styleUrls: ['./my-inbox.component.css']
})
export class MyInboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
