export class Report {
    reportCategory: string;
    reportStauts: string;
    reportYear: string;
    reportQuarter: string;
    reportMonth: string;
    userId: string;
}
