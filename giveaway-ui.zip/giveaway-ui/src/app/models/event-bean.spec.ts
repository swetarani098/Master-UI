import { EventBean } from './event-bean';

describe('EventBean', () => {
  it('should create an instance', () => {
    expect(new EventBean()).toBeTruthy();
  });
});
