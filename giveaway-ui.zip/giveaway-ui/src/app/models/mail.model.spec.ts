import { Mail } from './mail.model';

describe('Mail', () => {
  it('should create an instance', () => {
    expect(new Mail()).toBeTruthy();
  });
});
