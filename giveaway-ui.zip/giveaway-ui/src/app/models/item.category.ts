export class ItemCategory {
    /* id: number;
    typeId: number;
    typeCode: string;
    typeDescription: string;*/
    
    constructor(public id: number, public typeId: number, public typeCode: string, public typeDescription: string) {

    }
}