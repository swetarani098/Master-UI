export class EventBean {
    id: string;
    eveName: string;
    eveDescription: string;
    startDate: Date;
    endDate: Date;
    address: string;
    city: string;
    contactno: string;
    contactName: string;
    status:string;
    pic_url_1:string;
    pic_url_2:string;
    pic_url_3:string;
    pic_url_4:string;
}
