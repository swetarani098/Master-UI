export class Mail {
  recipentEmailId:string;
	senderEmailId:string;
	mailSubject:string;
	mailMessage:string;
	readStatus:string;
  userName:string;
  sendDate:Date;
}
