import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headermast',
  templateUrl: './headermast.component.html',
  styleUrls: ['./headermast.component.css']
})
export class HeadermastComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
