import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outreach-user-request',
  templateUrl: './outreach-user-request.component.html',
  styleUrls: ['./outreach-user-request.component.css']
})
export class OutreachUserRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
