package com.hackfse.giveaway.MailingSystem;

import org.springframework.context.annotation.Configuration;

@Configuration
public class MailingSystemConfig {

}
